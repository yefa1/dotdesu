#!/bin/bash
#
#
~/.xinitrc

